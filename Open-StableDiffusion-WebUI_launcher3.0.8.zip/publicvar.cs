﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Awake
{
    class publicvar
    {
        public static string _选中的模型名称 = "";
        public static string _选中的模型uuid = "";
        public static string _选中的模型作者头像地址 = "";
        public static string _选中的模型封面 = "";
    }
}
