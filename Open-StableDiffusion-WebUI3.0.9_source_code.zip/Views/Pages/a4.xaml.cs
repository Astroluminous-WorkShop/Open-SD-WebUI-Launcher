﻿namespace Awake.Views.Pages
{
    /// <summary>
    /// a4.xaml 的交互逻辑
    /// </summary>
    public partial class a4
    {
        public a4()
        {
            InitializeComponent();
        }
    }
}
