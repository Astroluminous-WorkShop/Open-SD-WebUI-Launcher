﻿namespace Awake.Views.Pages
{
    /// <summary>
    /// a2.xaml 的交互逻辑
    /// </summary>
    public partial class a2
    {
        public a2()
        {
            InitializeComponent();
        }
    }
}
